Many developers have contributed to the OpenUpgrade framework in its previous
incarnation. Their original contributions may no longer needed, or they are
no longer recognizable in their current form but OpenUpgrade would not have
existed at this point without them.
